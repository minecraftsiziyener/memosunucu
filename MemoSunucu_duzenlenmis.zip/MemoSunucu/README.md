# MemoSunucu (Paper 1.20.6 / Java 21)

Kayıt ve kral sistemleri kaldırılmıştır. Oyuncular normal giriş yapar.

## GitHub üzerinden JAR oluşturma
1. Bu klasörün içeriğini GitHub deposunun kök dizinine yükle.
2. `Actions` sekmesine girip `Build plugin` iş akışını seç.
3. `Run workflow` ile başlat veya `main`/`master` dalına push yap.
4. Tamamlanınca ilgili çalışmayı aç, `Artifacts` bölümünden `MemoSunucu` dosyasını indir.
5. ZIP içindeki `MemoSunucu.jar` dosyasını sunucunun `plugins/` klasörüne koyup sunucuyu yeniden başlat.

## Özellikler
- `/tptr`: çevrimiçi oyuncular menüsü üzerinden yanına ışınlanma
- `/ai <soru>` veya sohbette `@ai <soru>`: TurkishAI
- `/aiapi <anahtar>`: API anahtarını ayarlama (yetkili)
- `/votekick <oyuncu>`: yapılandırılmış oy sayısı ile oyuncu atma
- `/evkur`, `/ev`: ev konumu kaydetme ve dönme
- `/rtp`: rastgele konuma ışınlanma
- Web API: `/api/status`, `/api/players`

Ayarlar `plugins/MemoSunucu/config.yml` dosyasındadır. Paper 1.20.6 ve Java 21 hedeflenmiştir.
